package com.vanrui.config;

import com.alibaba.druid.pool.DruidDataSource;
import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

/**
 * Created by xuyao on 29/01/2018.
 */
@Configuration
//@MapperScan(basePackages = "com.vanrui.h2mapper", annotationClass =H2DB.class, sqlSessionFactoryRef = H2DBConfiguration.SQL_SESSION_FACTORY_NAME)
@MapperScan(basePackages = "com.vanrui.h2mapper", sqlSessionFactoryRef = H2DBConfiguration.SQL_SESSION_FACTORY_NAME)
public class H2DBConfiguration {

    public static final String SQL_SESSION_FACTORY_NAME = "h2DBSessionFactory";
    //    public static final String TX_MANAGER = "h2DBTransactionManager";
    public static final String DATA_SOURCE = "h2DBDataSource";
//    public static final String SQL_SESSION_TEMPLATE = "h2DBSessionTemplate";

    @Autowired
    private Environment env;

    @Bean(name = DATA_SOURCE)
    public DataSource getH2DataSource() {
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(env.getProperty("spring.datasource.driver-class-name"));
        ds.setUrl(env.getProperty("spring.datasource.url"));
        ds.setUsername(env.getProperty("spring.datasource.username"));
        ds.setPassword(env.getProperty("spring.datasource.password"));
        return ds;
    }

    @Bean(name = SQL_SESSION_FACTORY_NAME)
    public SqlSessionFactory sqlSessionFactory(@Qualifier(DATA_SOURCE) DataSource ds)
        throws Exception {
        SqlSessionFactoryBean fb = new SqlSessionFactoryBean();
        fb.setDataSource(ds);//指定数据源(这个必须有，否则报错)

        //下边两句仅仅用于*.xml文件，如果整个持久层操作不需要使用到xml文件的话（只用注解就可以搞定），则不加
        fb.setTypeAliasesPackage(env.getProperty("mybatis.h2.basePackage"));//指定基包
        fb.setMapperLocations(new PathMatchingResourcePatternResolver()
            .getResources(env.getProperty("mybatis.h2.mapperLocations")));//指定xml文件位置

        return fb.getObject();
    }
}
