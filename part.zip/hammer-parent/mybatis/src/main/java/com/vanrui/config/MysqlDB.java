package com.vanrui.config;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by xuyao on 30/01/2018.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface MysqlDB {

}
