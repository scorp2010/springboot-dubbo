package com.vanrui.common.config;

import com.vanrui.auth.FilterAnnotationBeanPostProcessor;
import com.vanrui.auth.FilterConfig;
import com.vanrui.auth.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterAutoConfiguration {

  @Bean
  FilterAnnotationBeanPostProcessor filterAnnotationBeanPostProcessor() {
    return new FilterAnnotationBeanPostProcessor();
  }

  @Bean
  public FilterConfig filterConfig() {
    return new FilterConfig();
  }

  @Bean
  JwtFilter jwtFilter() {
    return new JwtFilter();
  }

}
