package com.vanrui.common.event;

/**
 * Created by xuyao on 13/12/2017.
 */
public  class GuavaEvent {

}
