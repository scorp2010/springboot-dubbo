package com.vanrui.controller;

import com.vanrui.h2mapper.H2UserMapper;
import com.vanrui.h2model.H2User;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by xuyao on 29/01/2018.
 */
@RestController
@RequestMapping(value="/h2")
public class H2UserController {
    @Autowired
    private H2UserMapper h2UserMapper;

    private Logger LOG = LoggerFactory.getLogger(getClass());

    @PostMapping(value="/adduser", consumes="application/json", produces="application/json")
    @ResponseBody public H2User addUser(@RequestBody H2User h2user){
        h2UserMapper.insertUser(h2user);
        H2User newUser = h2UserMapper.findByState(h2user.getState());
        LOG.info("new User: " + newUser);
        return newUser;
    }

    @PostMapping(value="/alluser", consumes="application/json", produces="application/json")
    @ResponseBody
    public List<H2User> allUser(@RequestBody H2User h2user){
        h2UserMapper.insertUser(h2user);
        List<H2User> newUser = h2UserMapper.getAllUsers();
        LOG.info("new User: " + newUser.get(0));
        return newUser;
    }

    @PostMapping(value="/getusers", consumes="application/json")
    @ResponseBody public List<H2User> getUsers(@RequestBody H2User user){

//        addUser();
        addUserXml();
        System.out.println("Total User count: "+ h2UserMapper.getUserCount());
        //List<String> states = Arrays.asList(h2user.getState().split("\\s*,\\s*"));
        String[] states = user.getState().split(",", -1);
        List<H2User> usrs = h2UserMapper.findByStates(states);
        System.out.println("User: "+ usrs);

        return usrs;
    }

    private void addUserXml(){
        H2User user = new H2User();
        user.setName("Webx111");
        user.setState("London");
        user.setCountry("UK");

        h2UserMapper.insertSelective(user);
        user = new H2User();
        user.setName("Webo");
        user.setState("Delhi");

        h2UserMapper.insertSelective(user);
    }

    private void addUser(){
        H2User user = new H2User();
        user.setName("Webx");
        user.setState("London");
        user.setCountry("UK");

        h2UserMapper.insertUser(user);
        user = new H2User();
        user.setName("Webo");
        user.setState("Delhi");
        user.setCountry("India");

        h2UserMapper.insertUser(user);
    }
}
