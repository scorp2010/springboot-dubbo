package com.vanrui.h2mapper;

import com.vanrui.h2model.H2User;
import java.util.List;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

//@H2DB
//@MysqlDB
//@Mapper
public interface H2UserMapper {

    @Select("SELECT * FROM h2user WHERE state = #{state}")
    H2User findByState(@Param("state") String state);

    //@Select("SELECT * FROM h2user WHERE state in ( #{state} )")
    //List<User> findByStates(@Param("state") String state);

    @Select({"<script>",
        "SELECT *",
        "FROM h2user",
        "WHERE state IN",
        "<foreach item='item' index='index' collection='states'",
        "open='(' separator=',' close=')'>",
        "#{item}",
        "</foreach>",
        "</script>"})
    List<H2User> findByStates(@Param("states") String[] states);

    @Insert("INSERT INTO h2user(name,state,country) VALUES(#{name},#{state},#{country})")
    @SelectKey(statement = "call identity()", keyProperty = "id", before = false, resultType = Integer.class)
    void insertUser(H2User user);

    @Select("SELECT * FROM h2user")
    List<H2User> getAllUsers();

    @Select("SELECT count(*) FROM h2user")
    int getUserCount();

    int insertSelective(H2User record);

}
