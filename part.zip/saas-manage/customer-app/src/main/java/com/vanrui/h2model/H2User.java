package com.vanrui.h2model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by xuyao on 29/01/2018.
 */
@Getter
@Setter
@ToString
public class H2User implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;

    private String name;

    private String state;

    private String country;

}
