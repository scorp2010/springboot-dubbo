package com.vanrui.test;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.joda.time.LocalDate;

/**
 * Created by xuyao on 2017/9/26.
 */
public class Test {

    public static void main(String[] args) throws ParseException {
        System.out.println(180%60);
        long lo = 1L << 62;
        System.out.println(lo);
        long tt = (1L << 39) / (1000L * 60 * 60 * 24 * 365);
        System.out.println(tt);
        long year = 1000L * 60 * 60 * 24 * 365*10;
        System.out.println(year);
        System.out.println(Long.toBinaryString(year));

        final long workerIdBits = 5L;
        long maxWorkerId = -1L ^ (-1L << workerIdBits);
        System.out.println(maxWorkerId);
        long sequenceBits = 12L;
        long sequenceMask = ~(-1L << sequenceBits);
        System.out.println(sequenceMask);
        long sequence = 0;
        sequence=(sequence + 1) & sequenceMask;
        System.out.println(sequence);

        int a = 2;
        System.out.println(~a);
        long start = System.currentTimeMillis();
//        long twepoch = 1420041600000L;
        long twepoch = 0L;
        long ret = start - twepoch;
        System.out.println(ret);
        System.out.println(Long.toBinaryString(ret));
        long reto = ret << 22;
        System.out.println(reto);
        System.out.println(Long.toBinaryString(reto)+"\n");
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(twepoch);
        String ds = sdf.format(date);
        System.out.println(ds);
        String er1= "10101111010111101011100000011101011011001";
        String er= "01111111111111111111111111111111";
        BigInteger bigInteger = new BigInteger(er);
        long dmy = Long.parseLong(er,2);
        String dmys = sdf.format(new Date(dmy));
        System.out.println(dmy);
        System.out.println(dmys);

        LocalDate localDate = LocalDate.parse("2017-10-30");
        long sss=sdf.parse("2017-10-30").getTime();
        System.out.println("year long:"+sss);
    }

}
