package com.vanrui.service;

import com.vanrui.mapper.TestInfoMapper;
import com.vanrui.model.TestInfo;
import com.vanrui.user.model.TestInfoVO;
import com.vanrui.user.service.TestDubboInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by xuyao on 2017/6/26.
 */
@Service("testDubboInfoService")
public class TestInfoServiceImpl implements TestDubboInfoService
{

    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TestInfoMapper testInfoMapper;

    @Override
    public void insertInfo(TestInfoVO testInfo) {
        log.info("----dubbo-----:{}",testInfo.toString());
        TestInfo testInfo1 = new TestInfo();
        BeanUtils.copyProperties(testInfo, testInfo1);
        testInfoMapper.insert(testInfo1);
    }

//    @Override
//    public List<TestInfo> queryList() {
//        log.info("查询所有,分页查询开始");
//        log.info("query page end");
//        return testInfoMapper.queryByParams();
//    }


}
