-- DROP TABLE IF EXISTS `test_info`;
-- CREATE TABLE `test_info` (
--   `Id` int(11) NOT NULL AUTO_INCREMENT,
--   `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
--   `password` varchar(32) DEFAULT NULL COMMENT '密码',
--   `usertype` varchar(2) DEFAULT NULL COMMENT '用户类型',
--   `enabled` int(2) DEFAULT NULL COMMENT '是否可用',
--   `realname` varchar(32) DEFAULT NULL COMMENT '真实姓名',
--   `qq` varchar(14) DEFAULT NULL COMMENT 'QQ',
--   `email` varchar(100) DEFAULT NULL,
--   `tel` varchar(255) DEFAULT NULL COMMENT '联系电话',
--   `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
--   `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
--   PRIMARY KEY (`Id`)
-- ) COMMENT='用户信息表';

-- drop table if exists h2user;
-- -- create table h2user (id int primary key auto_increment, name varchar(32), state varchar(32), country varchar(32));
-- create table h2user (id int primary key auto_increment, name varchar, state varchar, country varchar);

create table if not exists user2sdd (id int not null primary key auto_increment,username varchar(100),password varchar(100),status int)