package com.vanrui.user.model;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 实体类对应的数据表为：  test_info
 * @author
 *
 *  @date:
 */
@Setter
@Getter
@ToString
//@Data
public class TestInfoVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;

    private String username;

    private String password;

    private String usertype;

    private Integer enabled;

    private String realname;

    private String qq;

    private String email;

    private String tel;

    private Date updateTime;

    private Date createTime;

/*
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [--");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", username=").append(username);
        sb.append(", password=").append(password);
        sb.append(", usertype=").append(usertype);
        sb.append(", enabled=").append(enabled);
        sb.append(", realname=").append(realname);
        sb.append(", qq=").append(qq);
        sb.append(", email=").append(email);
        sb.append(", tel=").append(tel);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createTime=").append(createTime);
        sb.append("]");
        return sb.toString();
    }*/
}