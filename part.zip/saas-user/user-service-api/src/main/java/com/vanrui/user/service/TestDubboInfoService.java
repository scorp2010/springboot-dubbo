package com.vanrui.user.service;

import com.vanrui.user.model.TestInfoVO;

/**
 * Created by xuyao on 2017/6/26.
 * 例子
 */
public interface TestDubboInfoService {

    /**
     *
     * @param testInfo
     */
    void insertInfo(TestInfoVO testInfo);

    /**
     * 分页查询
     */
//    List<TestInfo> queryList();
}
